'use strict'

module.exports = {
  mailer: {
    service: 'Gmail',
    auth: {
      user: 'YOUR_GMAIL_ADDRESS',
      pass: 'YOUR_GMAIL_PASSWORD'
    }
  }
}
