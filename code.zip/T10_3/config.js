'use strict'

module.exports = {
  mailer: {
    service: 'Gmail',
    auth: {
      user: 'YOUR_GMAIL_ADDRESS',
      pass: 'YOUR_GMAIL_PASSWORD'
    }
  },
  dbConnstring: 'mongodb://admin:123@ds137760.mlab.com:37760/code4share',
  sessionKey: 'HaloCode4Share'
}
